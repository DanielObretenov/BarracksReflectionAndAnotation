package barracksWars.core.commands;

import barracksWars.interfaces.Executable;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

public abstract class Command implements Executable {
    protected String []data ;
    protected Repository repository;
    protected UnitFactory unitFactory;

    public Command(String[] data, Repository repository, UnitFactory unitFactory){
        this.data = data;
        this.repository =repository;
        this.unitFactory = unitFactory;
    }
}
