package barracksWars.core;

import barracksWars.interfaces.Executable;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.Runnable;
import barracksWars.interfaces.UnitFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {

	private Repository repository;
	private UnitFactory unitFactory;
	private static final String COMMAND_PATH = "barracksWars.core.commands.";


	public Engine(Repository repository, UnitFactory unitFactory) {
		this.repository = repository;
		this.unitFactory = unitFactory;
	}

	@Override
	public void run() {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(System.in));
		while (true) {
			try {
				String input = reader.readLine();
				String[] data = input.split("\\s+");
				String commandName = data[0];
				String result = interpretCommand(data, commandName);
				assert result != null;
				if (result.equals("fight")) {
					break;
				}
				System.out.println(result);
			} catch (RuntimeException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private String interpretCommand(String[] data, String commandName) {

		commandName = commandName.substring(0,1).toUpperCase() + commandName.substring(1).toLowerCase();
		try {
			Class<?> commandClass = Class.forName(COMMAND_PATH + commandName);
			Constructor<?> declaredConstructor = commandClass.getDeclaredConstructor(String[].class, Repository.class, UnitFactory.class);
			Object obj = declaredConstructor.newInstance(data, this.repository, this.unitFactory);
			if (obj instanceof Executable) {
				Executable executable = (Executable) obj;
				return executable.execute();
			}
		} catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | InvocationTargetException | IllegalAccessException e) {
			throw new RuntimeException("No such command " + commandName);
		}

		return null;
	}
}



		//String result;


//		switch (commandName) {
//			case "add":
//				result =  new Add(data,this.repository,this.unitFactory).execute();
//				break;
//			case "report":
//				result = new Report(data,this.repository,this.unitFactory).execute();
//				break;
//			case "fight":
//				result = new Fight(data,this.repository,this.unitFactory).execute();
//				break;
//			default:
//				throw new RuntimeException("Invalid command!");
//		}
//		return result;

